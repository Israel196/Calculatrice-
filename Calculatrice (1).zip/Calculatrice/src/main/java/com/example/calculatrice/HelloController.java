package com.example.calculatrice;

import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;

public class HelloController {
    @FXML
    private Label welcomeText;
    @FXML
    TextArea inputCaracter = new TextArea();

    @FXML
    protected void onHelloButtonClick() {
        String input = inputCaracter.getText();
        try {
            Double result = 0.0;
            if(input == null || input.isBlank() || input.contains("a") || input.contains("c")
                    || input.contains("d")
                    || input.contains("e")
                    || input.contains("f")
                    || input.contains("g")
                    || input.contains("h")
                    || input.contains("i") || input.contains("j") || input.contains("k")  || input.contains("m") || input.contains("n") || input.contains("o") || input.contains("p") || input.contains("q") || input.contains("r")  || input.contains("u")
                    || input.contains("w") || input.contains("x") || input.contains("y") || input.contains("z")){
                welcomeText.setText("Please Enter Value");
            }
            else{
                Model app = new Model(input);
                result = app.evaluationOfExpression(input);
                welcomeText.setText(String.valueOf(result));
                //System.out.println("kiii: "+ result);
            }
            if(result == -1111.0){
                welcomeText.setText("Erreur");
            }
            else  if(result == -3.0){
                welcomeText.setText("Erreur Input");
            }

        } catch (NullPointerException e) {
            System.out.println("NullPointerException Caught");
        }

    }

    @FXML
    protected void onResetButtonClick() {

        inputCaracter.clear();

        welcomeText.setText("");
    }

}